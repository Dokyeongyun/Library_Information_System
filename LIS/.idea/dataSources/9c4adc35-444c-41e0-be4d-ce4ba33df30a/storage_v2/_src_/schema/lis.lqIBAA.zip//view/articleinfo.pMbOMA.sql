create definer = root@localhost view articleinfo as
select `a`.`articleId`  AS `articleId`,
       `a`.`boardId`    AS `boardId`,
       `a`.`writer`     AS `writer`,
       `a`.`title`      AS `title`,
       `a`.`content`    AS `content`,
       `a`.`hit`        AS `hit`,
       `a`.`attachFile` AS `attachFile`,
       `a`.`regDate`    AS `regDate`,
       `b`.`boardName`  AS `boardName`
from `lis`.`board` `b`
         join `lis`.`article` `a`
where (`b`.`boardId` = `a`.`boardId`);

